module labtest_q1_hardware(a,b,c,x,y);
    input a,b;
    output reg x,y,z;
    
    wire[2:0] temp; //this is an optional wire you may/may not wish to use
    
    // complete the rest of the code
     assign temp = {};
     
     always @(temp) begin
        case (temp)
            3'b00       : begin x = 1'b ; end 
            3'b01       : begin x = 1'b ; end 
            default     : begin x = 1'b ; end 
        endcase
    end

endmodule

